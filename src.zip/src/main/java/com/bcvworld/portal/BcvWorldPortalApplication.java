package com.bcvworld.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BcvWorldPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(BcvWorldPortalApplication.class, args);
	}

}
