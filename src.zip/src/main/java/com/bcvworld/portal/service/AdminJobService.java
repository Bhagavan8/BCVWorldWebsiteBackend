package com.bcvworld.portal.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcvworld.portal.model.Job;
import com.bcvworld.portal.repository.JobRepository;

@Service
public class AdminJobService {

    @Autowired
    private JobRepository jobRepository;

    public Job saveJob(Job job) {

        // Generate Job ID if missing
        if (job.getJobId() == null || job.getJobId().trim().isEmpty()) {
            job.setJobId(generateUniqueJobId());
        }

        // Set posted date
        if (job.getPostedDate() == null) {
            job.setPostedDate(LocalDate.now());
        }

        // 🔴 FIX: applyLink is REQUIRED (NOT NULL)
        if (job.getApplyLink() == null || job.getApplyLink().trim().isEmpty()) {
            throw new RuntimeException("Application link or email is required");
        }

        return jobRepository.save(job);
    }


    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    public Optional<Job> getJobById(Long id) {
        return jobRepository.findById(id);
    }

    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }

    private String generateUniqueJobId() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        for (int attempts = 0; attempts < 1000; attempts++) {
            StringBuilder sb = new StringBuilder(10);
            for (int i = 0; i < 10; i++) {
                sb.append(chars.charAt(
                    ThreadLocalRandom.current().nextInt(chars.length())
                ));
            }
            String id = sb.toString();
            if (!jobRepository.existsByJobId(id)) {
                return id;
            }
        }
        throw new RuntimeException("Unable to generate unique job ID");
    }

}
