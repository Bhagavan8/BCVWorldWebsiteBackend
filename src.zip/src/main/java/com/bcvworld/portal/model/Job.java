package com.bcvworld.portal.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "jobs")
public class Job {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Admin's unique string ID
    @Column(unique = true)
    private String jobId;

    // Maps to job_title
    @Column(name = "job_title", nullable = false)
    private String jobTitle;

    // Maps to company_name
    @Column(name = "company_name")
    private String companyName;

    @ElementCollection
    @CollectionTable(name = "job_locations", joinColumns = @JoinColumn(name = "job_id"))
    @Column(name = "location")
    private List<String> locations;

    // Maps to job_category
    @Column(name = "job_category", nullable = false)
    private String jobCategory; 

    // Maps to job_type
    @Column(name = "job_type", nullable = false)
    private String jobType; 

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    // Admin: employmentType
    private String employmentType;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate postedDate;

    @Column(name = "company_logo_url")
    private String logoUrl;

    // Maps to application_link_or_email
    @Column(name = "application_link_or_email", nullable = false)
    private String applyLink;

    // Maps to referral_code
    @Column(name = "referral_code")
    private String referralCode;
    
    @Column(length = 5000, nullable = false)
    private String description;
    
    @Column(length = 5000)
    private String details;
    
    @Column(length = 5000, name = "about_company")
    private String aboutCompany;

    @Column(name = "company_website")
    private String companyWebsite;

    @Column(length = 5000, nullable = false)
    private String skills;
    
    @Column(length = 5000, nullable = false)
    private String qualifications;

    @ElementCollection
    @CollectionTable(name = "job_education_levels", joinColumns = @JoinColumn(name = "job_id"))
    @Column(name = "education_level")
    private List<String> educationLevels;

    @Column(name = "experience_required", nullable = false)
    private String experience;

    @Column(name = "salary_range")
    private String salary;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate lastDateToApply;
    
    private Integer viewCount = 0;
    private Integer likeCount = 0;

    @Transient
    private boolean isLiked = false;
    
    public boolean getIsLiked() { return isLiked; }
    public void setIsLiked(boolean isLiked) { this.isLiked = isLiked; }

    // Admin extra fields
    private String noticePeriod;
    @Column(columnDefinition = "TEXT")
    private String walkinDetails;
    private boolean useExistingCompany;
    private Long companyId;
    private String applicationMethod;
    private String listingStatus; 
    private boolean isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public List<String> getLocations() {
		return locations;
	}

	public void setLocations(List<String> locations) {
		this.locations = locations;
	}

	public String getJobCategory() {
		return jobCategory;
	}

	public void setJobCategory(String jobCategory) {
		this.jobCategory = jobCategory;
	}

	public String getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}

	public LocalDate getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(LocalDate postedDate) {
		this.postedDate = postedDate;
	}

	public String getLogoUrl() {
		return logoUrl;
	}

	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}

	public String getApplyLink() {
		return applyLink;
	}

	public void setApplyLink(String applyLink) {
		this.applyLink = applyLink;
	}

	public String getReferralCode() {
		return referralCode;
	}

	public void setReferralCode(String referralCode) {
		this.referralCode = referralCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getAboutCompany() {
		return aboutCompany;
	}

	public void setAboutCompany(String aboutCompany) {
		this.aboutCompany = aboutCompany;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getQualifications() {
		return qualifications;
	}

	public void setQualifications(String qualifications) {
		this.qualifications = qualifications;
	}

	public List<String> getEducationLevels() {
		return educationLevels;
	}

	public void setEducationLevels(List<String> educationLevels) {
		this.educationLevels = educationLevels;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public LocalDate getLastDateToApply() {
		return lastDateToApply;
	}

	public void setLastDateToApply(LocalDate lastDateToApply) {
		this.lastDateToApply = lastDateToApply;
	}

	public Integer getViewCount() {
		return viewCount;
	}

	public void setViewCount(Integer viewCount) {
		this.viewCount = viewCount;
	}

	public Integer getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(Integer likeCount) {
		this.likeCount = likeCount;
	}

	public String getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(String noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public String getWalkinDetails() {
		return walkinDetails;
	}

	public void setWalkinDetails(String walkinDetails) {
		this.walkinDetails = walkinDetails;
	}

	public boolean isUseExistingCompany() {
		return useExistingCompany;
	}

	public void setUseExistingCompany(boolean useExistingCompany) {
		this.useExistingCompany = useExistingCompany;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getApplicationMethod() {
		return applicationMethod;
	}

	public void setApplicationMethod(String applicationMethod) {
		this.applicationMethod = applicationMethod;
	}

	public String getListingStatus() {
		return listingStatus;
	}

	public void setListingStatus(String listingStatus) {
		this.listingStatus = listingStatus;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public void setLiked(boolean isLiked) {
		this.isLiked = isLiked;
	}

    // Compatibility methods removed
    
}
